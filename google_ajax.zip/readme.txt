=== Custom Google Ajax Rss Feed ===
Contributors: anuragRajat
Donate link: 
Tags: google ajax feed
Requires at least: 3.3
Tested up to: 3.4
Stable tag: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Google Ajax Feed is for display google ajax rss feed vertically or horizontally

== Description ==

Google Ajax Feed is for display google ajax rss feed vertically or horizontally

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go To widget and manage your settings

== Frequently asked questions ==



== Screenshots ==

1. 
2. 

== Changelog ==



== Upgrade notice ==



== Arbitrary section 1 ==


